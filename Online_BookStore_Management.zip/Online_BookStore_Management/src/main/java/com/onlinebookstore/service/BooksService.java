package com.onlinebookstore.service;

import com.onlinebookstore.entity.Book;

public interface BooksService {

	public Book createRegistartion(Book book);
	
	
	

}
